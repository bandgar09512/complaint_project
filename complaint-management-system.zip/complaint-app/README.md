# 📋 Complaint Management System

A full-stack Complaint Management System built with **Next.js**, **Node.js (Express)**, and **PostgreSQL**.

---

## 📁 Project Structure

```
complaint-app/
├── backend/                    # Node.js + Express REST API
│   ├── src/
│   │   ├── server.js           # Express app entry point
│   │   ├── db.js               # PostgreSQL connection
│   │   ├── complaintRoutes.js  # API route definitions
│   │   └── complaintController.js  # Business logic / CRUD
│   ├── database.sql            # SQL schema + sample data
│   ├── .env.example            # Environment variables template
│   └── package.json
│
├── frontend/                   # Next.js 14 App Router
│   ├── src/
│   │   ├── app/
│   │   │   ├── page.js                          # Home - complaints list
│   │   │   ├── api.js                           # Axios service
│   │   │   ├── layout.js
│   │   │   └── complaints/
│   │   │       ├── new/page.js                  # Create complaint
│   │   │       └── [id]/
│   │   │           ├── page.js                  # View complaint
│   │   │           └── edit/page.js             # Edit complaint
│   │   └── components/
│   │       └── ComplaintForm.js                 # Reusable form component
│   ├── .env.local.example
│   └── package.json
│
└── Complaint_API.postman_collection.json        # Postman collection
```

---

## 🚀 Quick Setup

### Prerequisites
- Node.js v18+
- PostgreSQL v14+
- npm or yarn

---

### 1️⃣ Database Setup

```sql
-- Open psql and run:
CREATE DATABASE complaint_db;

-- Connect to the new database:
\c complaint_db

-- Run the schema file:
\i /path/to/complaint-app/backend/database.sql
```

---

### 2️⃣ Backend Setup

```bash
cd backend

# Install dependencies
npm install

# Create env file
cp .env.example .env

# Edit .env with your database credentials:
# DB_HOST=localhost
# DB_PORT=5432
# DB_NAME=complaint_db
# DB_USER=postgres
# DB_PASSWORD=your_password
# PORT=5000

# Start server
npm run dev      # Development (nodemon)
npm start        # Production
```

Server runs at: **http://localhost:5000**

---

### 3️⃣ Frontend Setup

```bash
cd frontend

# Install dependencies
npm install

# Create env file
cp .env.local.example .env.local

# Edit .env.local:
# NEXT_PUBLIC_API_URL=http://localhost:5000/api

# Start development server
npm run dev
```

Frontend runs at: **http://localhost:3000**

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/complaints` | Get all complaints (paginated, filterable) |
| GET | `/api/complaints/stats` | Get complaint statistics |
| GET | `/api/complaints/:id` | Get single complaint by ID |
| POST | `/api/complaints` | Create new complaint |
| PUT | `/api/complaints/:id` | Full update of complaint |
| PATCH | `/api/complaints/:id/status` | Update status only |
| DELETE | `/api/complaints/:id` | Delete complaint |

### Query Parameters (GET /api/complaints)
| Param | Values | Example |
|-------|--------|---------|
| `status` | Pending, In Progress, Resolved, Rejected | `?status=Pending` |
| `priority` | High, Medium, Low | `?priority=High` |
| `category` | any string (partial match) | `?category=Billing` |
| `page` | number (default: 1) | `?page=2` |
| `limit` | number (default: 10) | `?limit=5` |

---

## 📬 Testing with Postman

1. Open **Postman**
2. Click **Import**
3. Select `Complaint_API.postman_collection.json`
4. The base URL is pre-set to `http://localhost:5000/api`
5. Run requests in order: **Create → Read → Update → Delete**

---

## 📝 Request Body Examples

### Create Complaint (POST)
```json
{
  "name": "Rahul Sharma",
  "email": "rahul@example.com",
  "phone": "9876543210",
  "category": "Product",
  "subject": "Received wrong product",
  "description": "I ordered a blue shirt but received a red one.",
  "priority": "High"
}
```

### Update Complaint (PUT)
```json
{
  "name": "Rahul Sharma",
  "email": "rahul@example.com",
  "category": "Service",
  "subject": "Updated subject",
  "description": "Updated description.",
  "status": "In Progress",
  "priority": "Medium"
}
```

### Update Status Only (PATCH)
```json
{
  "status": "Resolved"
}
```

---

## ✅ Valid Field Values

| Field | Valid Values |
|-------|-------------|
| `status` | `Pending`, `In Progress`, `Resolved`, `Rejected` |
| `priority` | `Low`, `Medium`, `High` |
| `category` | `Product`, `Service`, `Billing`, `Delivery`, `Technical`, `Other` |

---

## 🌐 Frontend Features

- **Dashboard** — View all complaints with filters and pagination
- **Stats Panel** — Live counts by status
- **Create Complaint** — Form with validation
- **View Complaint** — Detailed view with inline status update
- **Edit Complaint** — Update all fields
- **Delete** — With confirmation dialog

---

## 🛠 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React 18, Tailwind CSS, Axios |
| Backend | Node.js, Express.js |
| Database | PostgreSQL |
| ORM/Driver | node-postgres (pg) |
