'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { complaintService } from '../../../api';

const STATUS_COLORS = {
  Pending: 'bg-yellow-100 text-yellow-800',
  'In Progress': 'bg-blue-100 text-blue-800',
  Resolved: 'bg-green-100 text-green-800',
  Rejected: 'bg-red-100 text-red-800',
};

const PRIORITY_COLORS = {
  High: 'bg-red-100 text-red-700',
  Medium: 'bg-orange-100 text-orange-700',
  Low: 'bg-gray-100 text-gray-700',
};

export default function ViewComplaintPage({ params }) {
  const router = useRouter();
  const { id } = params;
  const [complaint, setComplaint] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [statusUpdating, setStatusUpdating] = useState(false);

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await complaintService.getById(id);
        setComplaint(res.data.data);
      } catch (err) {
        setError(err.response?.data?.message || 'Complaint not found');
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [id]);

  const handleStatusChange = async (newStatus) => {
    try {
      setStatusUpdating(true);
      const res = await complaintService.updateStatus(id, newStatus);
      setComplaint(res.data.data);
    } catch {
      setError('Failed to update status');
    } finally {
      setStatusUpdating(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm('Delete this complaint?')) return;
    try {
      await complaintService.delete(id);
      router.push('/');
    } catch {
      setError('Failed to delete');
    }
  };

  if (loading) return <div className="max-w-3xl mx-auto px-4 py-16 text-center text-gray-400">Loading...</div>;
  if (error) return <div className="max-w-3xl mx-auto px-4 py-16 text-center text-red-500">{error}</div>;

  return (
    <div className="max-w-3xl mx-auto px-4 py-10">
      <div className="flex justify-between items-start mb-6">
        <div>
          <Link href="/" className="text-blue-600 hover:underline text-sm">← Back to Complaints</Link>
          <h1 className="text-2xl font-bold text-gray-900 mt-2">Complaint #{complaint.id}</h1>
          <p className="text-gray-400 text-sm mt-0.5">
            Submitted on {new Date(complaint.created_at).toLocaleString()}
          </p>
        </div>
        <div className="flex gap-2">
          <Link href={`/complaints/${id}/edit`}
            className="px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700">
            Edit
          </Link>
          <button onClick={handleDelete}
            className="px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600">
            Delete
          </button>
        </div>
      </div>

      <div className="bg-white rounded-2xl border shadow-sm overflow-hidden">
        {/* Status bar */}
        <div className="bg-gray-50 border-b px-6 py-4 flex flex-wrap gap-3 items-center justify-between">
          <div className="flex gap-3">
            <span className={`px-3 py-1 rounded-full text-xs font-semibold ${STATUS_COLORS[complaint.status]}`}>
              {complaint.status}
            </span>
            <span className={`px-3 py-1 rounded-full text-xs font-semibold ${PRIORITY_COLORS[complaint.priority]}`}>
              {complaint.priority} Priority
            </span>
            <span className="px-3 py-1 rounded-full text-xs font-semibold bg-purple-100 text-purple-700">
              {complaint.category}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">Update status:</span>
            <select value={complaint.status} onChange={e => handleStatusChange(e.target.value)}
              disabled={statusUpdating}
              className="border rounded-lg px-2 py-1 text-xs text-gray-700 focus:outline-none focus:ring-1 focus:ring-blue-500">
              {['Pending', 'In Progress', 'Resolved', 'Rejected'].map(s => <option key={s}>{s}</option>)}
            </select>
          </div>
        </div>

        {/* Details */}
        <div className="px-6 py-6 space-y-5">
          <div>
            <h2 className="text-lg font-semibold text-gray-900">{complaint.subject}</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
            <div>
              <div className="text-gray-400 text-xs uppercase tracking-wider mb-1">Name</div>
              <div className="font-medium text-gray-800">{complaint.name}</div>
            </div>
            <div>
              <div className="text-gray-400 text-xs uppercase tracking-wider mb-1">Email</div>
              <div className="font-medium text-gray-800">{complaint.email}</div>
            </div>
            <div>
              <div className="text-gray-400 text-xs uppercase tracking-wider mb-1">Phone</div>
              <div className="font-medium text-gray-800">{complaint.phone || '—'}</div>
            </div>
          </div>

          <div>
            <div className="text-gray-400 text-xs uppercase tracking-wider mb-2">Description</div>
            <div className="bg-gray-50 rounded-xl p-4 text-gray-700 text-sm leading-relaxed whitespace-pre-wrap">
              {complaint.description}
            </div>
          </div>

          <div className="text-xs text-gray-400 border-t pt-4">
            Last updated: {new Date(complaint.updated_at).toLocaleString()}
          </div>
        </div>
      </div>
    </div>
  );
}
