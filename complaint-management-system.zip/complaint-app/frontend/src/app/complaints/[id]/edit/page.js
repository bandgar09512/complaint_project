'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import ComplaintForm from '../../../../components/ComplaintForm';
import { complaintService } from '../../../api';

export default function EditComplaintPage({ params }) {
  const router = useRouter();
  const { id } = params;
  const [complaint, setComplaint] = useState(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetch = async () => {
      try {
        const res = await complaintService.getById(id);
        setComplaint(res.data.data);
      } catch (err) {
        setError(err.response?.data?.message || 'Complaint not found');
      } finally {
        setLoading(false);
      }
    };
    fetch();
  }, [id]);

  const handleSubmit = async (data) => {
    try {
      setSubmitting(true);
      setError('');
      await complaintService.update(id, data);
      router.push(`/complaints/${id}`);
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to update complaint');
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="max-w-2xl mx-auto px-4 py-16 text-center text-gray-400">Loading...</div>;
  if (error && !complaint) return <div className="max-w-2xl mx-auto px-4 py-16 text-center text-red-500">{error}</div>;

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <div className="mb-6">
        <Link href={`/complaints/${id}`} className="text-blue-600 hover:underline text-sm">
          ← Back to Complaint #{id}
        </Link>
        <h1 className="text-2xl font-bold text-gray-900 mt-2">Edit Complaint #{id}</h1>
        <p className="text-gray-500 text-sm mt-1">Update the complaint details below.</p>
      </div>

      {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">{error}</div>}

      <div className="bg-white rounded-2xl border p-6 shadow-sm">
        <ComplaintForm initialData={complaint} onSubmit={handleSubmit} loading={submitting} isEdit={true} />
      </div>
    </div>
  );
}
