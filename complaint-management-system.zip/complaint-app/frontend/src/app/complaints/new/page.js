'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import ComplaintForm from '../../../components/ComplaintForm';
import { complaintService } from '../../api';

export default function NewComplaintPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (data) => {
    try {
      setLoading(true);
      setError('');
      await complaintService.create(data);
      router.push('/?success=1');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to submit complaint');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-10">
      <div className="mb-6">
        <Link href="/" className="text-blue-600 hover:underline text-sm">← Back to Complaints</Link>
        <h1 className="text-2xl font-bold text-gray-900 mt-2">Submit New Complaint</h1>
        <p className="text-gray-500 text-sm mt-1">Fill in the details below to register your complaint.</p>
      </div>

      {error && <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-lg text-sm">{error}</div>}

      <div className="bg-white rounded-2xl border p-6 shadow-sm">
        <ComplaintForm onSubmit={handleSubmit} loading={loading} />
      </div>
    </div>
  );
}
