-- Create database (run this manually first)
-- CREATE DATABASE complaint_db;

-- Run this script after connecting to complaint_db
CREATE TABLE IF NOT EXISTS complaints (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(20),
  category VARCHAR(50) NOT NULL,
  subject VARCHAR(200) NOT NULL,
  description TEXT NOT NULL,
  status VARCHAR(20) DEFAULT 'Pending' CHECK (status IN ('Pending', 'In Progress', 'Resolved', 'Rejected')),
  priority VARCHAR(10) DEFAULT 'Medium' CHECK (priority IN ('Low', 'Medium', 'High')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Function to auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger
DROP TRIGGER IF EXISTS update_complaints_updated_at ON complaints;
CREATE TRIGGER update_complaints_updated_at
BEFORE UPDATE ON complaints
FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Sample data
INSERT INTO complaints (name, email, phone, category, subject, description, status, priority)
VALUES
  ('John Doe', 'john@example.com', '9876543210', 'Product', 'Defective item received', 'I received a damaged product. The box was torn and item was broken.', 'Pending', 'High'),
  ('Jane Smith', 'jane@example.com', '9123456789', 'Service', 'Poor customer service', 'Staff was rude and unhelpful during my visit.', 'In Progress', 'Medium'),
  ('Bob Wilson', 'bob@example.com', NULL, 'Billing', 'Double charged for order', 'I was charged twice for the same order #12345.', 'Resolved', 'High');
