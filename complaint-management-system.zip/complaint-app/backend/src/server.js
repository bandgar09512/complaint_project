const express = require('express');
const cors = require('cors');
require('dotenv').config();

const complaintRoutes = require('./complaintRoutes');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:3000',
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Health check
app.get('/', (req, res) => {
  res.json({
    message: '🚀 Complaint API is running',
    version: '1.0.0',
    endpoints: {
      complaints: '/api/complaints',
      stats: '/api/complaints/stats',
    },
  });
});

// Routes
app.use('/api/complaints', complaintRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ success: false, message: `Route ${req.originalUrl} not found` });
});

// Global error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, message: 'Internal server error', error: err.message });
});

app.listen(PORT, () => {
  console.log(`\n🚀 Server running at http://localhost:${PORT}`);
  console.log(`📋 API Base URL: http://localhost:${PORT}/api/complaints`);
  console.log(`📊 Stats URL:    http://localhost:${PORT}/api/complaints/stats\n`);
});
