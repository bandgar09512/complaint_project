const pool = require('../db');

// GET all complaints
const getAllComplaints = async (req, res) => {
  try {
    const { status, priority, category, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let query = 'SELECT * FROM complaints WHERE 1=1';
    const params = [];

    if (status) {
      params.push(status);
      query += ` AND status = $${params.length}`;
    }
    if (priority) {
      params.push(priority);
      query += ` AND priority = $${params.length}`;
    }
    if (category) {
      params.push(`%${category}%`);
      query += ` AND category ILIKE $${params.length}`;
    }

    // Count query
    const countResult = await pool.query(
      query.replace('SELECT *', 'SELECT COUNT(*)'),
      params
    );
    const total = parseInt(countResult.rows[0].count);

    // Data query with pagination
    params.push(parseInt(limit));
    params.push(parseInt(offset));
    query += ` ORDER BY created_at DESC LIMIT $${params.length - 1} OFFSET $${params.length}`;

    const result = await pool.query(query, params);

    res.status(200).json({
      success: true,
      total,
      page: parseInt(page),
      limit: parseInt(limit),
      totalPages: Math.ceil(total / limit),
      data: result.rows,
    });
  } catch (error) {
    console.error('getAllComplaints error:', error);
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};

// GET single complaint by ID
const getComplaintById = async (req, res) => {
  try {
    const { id } = req.params;
    const result = await pool.query('SELECT * FROM complaints WHERE id = $1', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: `Complaint with id ${id} not found` });
    }

    res.status(200).json({ success: true, data: result.rows[0] });
  } catch (error) {
    console.error('getComplaintById error:', error);
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};

// POST create complaint
const createComplaint = async (req, res) => {
  try {
    const { name, email, phone, category, subject, description, priority } = req.body;

    // Validation
    if (!name || !email || !category || !subject || !description) {
      return res.status(400).json({
        success: false,
        message: 'Required fields: name, email, category, subject, description',
      });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ success: false, message: 'Invalid email format' });
    }

    const result = await pool.query(
      `INSERT INTO complaints (name, email, phone, category, subject, description, priority)
       VALUES ($1, $2, $3, $4, $5, $6, $7)
       RETURNING *`,
      [name, email, phone || null, category, subject, description, priority || 'Medium']
    );

    res.status(201).json({
      success: true,
      message: 'Complaint submitted successfully',
      data: result.rows[0],
    });
  } catch (error) {
    console.error('createComplaint error:', error);
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};

// PUT update complaint
const updateComplaint = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, email, phone, category, subject, description, status, priority } = req.body;

    // Check existence
    const existing = await pool.query('SELECT * FROM complaints WHERE id = $1', [id]);
    if (existing.rows.length === 0) {
      return res.status(404).json({ success: false, message: `Complaint with id ${id} not found` });
    }

    const result = await pool.query(
      `UPDATE complaints
       SET name = COALESCE($1, name),
           email = COALESCE($2, email),
           phone = COALESCE($3, phone),
           category = COALESCE($4, category),
           subject = COALESCE($5, subject),
           description = COALESCE($6, description),
           status = COALESCE($7, status),
           priority = COALESCE($8, priority)
       WHERE id = $9
       RETURNING *`,
      [name, email, phone, category, subject, description, status, priority, id]
    );

    res.status(200).json({
      success: true,
      message: 'Complaint updated successfully',
      data: result.rows[0],
    });
  } catch (error) {
    console.error('updateComplaint error:', error);
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};

// PATCH update status only
const updateComplaintStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;

    const validStatuses = ['Pending', 'In Progress', 'Resolved', 'Rejected'];
    if (!status || !validStatuses.includes(status)) {
      return res.status(400).json({
        success: false,
        message: `Status must be one of: ${validStatuses.join(', ')}`,
      });
    }

    const result = await pool.query(
      'UPDATE complaints SET status = $1 WHERE id = $2 RETURNING *',
      [status, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: `Complaint with id ${id} not found` });
    }

    res.status(200).json({
      success: true,
      message: 'Status updated successfully',
      data: result.rows[0],
    });
  } catch (error) {
    console.error('updateComplaintStatus error:', error);
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};

// DELETE complaint
const deleteComplaint = async (req, res) => {
  try {
    const { id } = req.params;

    const result = await pool.query('DELETE FROM complaints WHERE id = $1 RETURNING *', [id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, message: `Complaint with id ${id} not found` });
    }

    res.status(200).json({
      success: true,
      message: `Complaint with id ${id} deleted successfully`,
      data: result.rows[0],
    });
  } catch (error) {
    console.error('deleteComplaint error:', error);
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};

// GET stats/summary
const getComplaintStats = async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT
        COUNT(*) AS total,
        COUNT(*) FILTER (WHERE status = 'Pending') AS pending,
        COUNT(*) FILTER (WHERE status = 'In Progress') AS in_progress,
        COUNT(*) FILTER (WHERE status = 'Resolved') AS resolved,
        COUNT(*) FILTER (WHERE status = 'Rejected') AS rejected,
        COUNT(*) FILTER (WHERE priority = 'High') AS high_priority,
        COUNT(*) FILTER (WHERE priority = 'Medium') AS medium_priority,
        COUNT(*) FILTER (WHERE priority = 'Low') AS low_priority
      FROM complaints
    `);

    const byCategory = await pool.query(`
      SELECT category, COUNT(*) as count
      FROM complaints
      GROUP BY category
      ORDER BY count DESC
    `);

    res.status(200).json({
      success: true,
      data: {
        summary: stats.rows[0],
        byCategory: byCategory.rows,
      },
    });
  } catch (error) {
    console.error('getComplaintStats error:', error);
    res.status(500).json({ success: false, message: 'Server error', error: error.message });
  }
};

module.exports = {
  getAllComplaints,
  getComplaintById,
  createComplaint,
  updateComplaint,
  updateComplaintStatus,
  deleteComplaint,
  getComplaintStats,
};
