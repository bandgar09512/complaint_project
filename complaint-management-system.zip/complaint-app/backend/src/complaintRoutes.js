const express = require('express');
const router = express.Router();
const {
  getAllComplaints,
  getComplaintById,
  createComplaint,
  updateComplaint,
  updateComplaintStatus,
  deleteComplaint,
  getComplaintStats,
} = require('./complaintController');

// @route   GET /api/complaints/stats
// @desc    Get complaint statistics
router.get('/stats', getComplaintStats);

// @route   GET /api/complaints
// @desc    Get all complaints (supports ?status=Pending&priority=High&category=Billing&page=1&limit=10)
router.get('/', getAllComplaints);

// @route   GET /api/complaints/:id
// @desc    Get single complaint by ID
router.get('/:id', getComplaintById);

// @route   POST /api/complaints
// @desc    Create new complaint
router.post('/', createComplaint);

// @route   PUT /api/complaints/:id
// @desc    Update full complaint
router.put('/:id', updateComplaint);

// @route   PATCH /api/complaints/:id/status
// @desc    Update complaint status only
router.patch('/:id/status', updateComplaintStatus);

// @route   DELETE /api/complaints/:id
// @desc    Delete complaint
router.delete('/:id', deleteComplaint);

module.exports = router;
